public class Main {
    public static void main(String[] args) {
        Persona persona = new Persona();
        persona.setTipo("persona");
        persona.setnombre("nataly");
        persona.settelefono(4566565);
        persona.setedad(31);

        String tipo = persona.getTipo();
        System.out.println(persona.getTipo());
        System.out.println(persona.getNombre());
        System.out.println(persona.getTelefono());
        System.out.println(persona.getedad());


    }

    }

class Persona {
    private String tipo;
    private String nombre;
    private String telefono;
    private Object edad;

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void settelefono(int telefono) {
        this.telefono = String.valueOf(telefono);
    }

    public String getTelefono() {
        return this.telefono;
    }

    public void setedad(int edad) {
        this.edad = edad;
    }

    public Object getedad() {
        Object edad1 = this.edad;
        return edad1;

    }
}


